Friend Module Constants

    Public Const sTHIS_APP As String = "rationaliser"

End Module
