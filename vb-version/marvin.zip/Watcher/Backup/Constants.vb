Friend Module Constants

    Public Const sTHIS_APP As String = "watcher"
    
End Module
