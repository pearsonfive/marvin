Friend Module Constants

    Public Const sTHIS_APP As String = "runner"

End Module
